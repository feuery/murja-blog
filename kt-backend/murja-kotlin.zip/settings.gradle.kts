rootProject.name = "net.feuerx.murja-kotlin"
